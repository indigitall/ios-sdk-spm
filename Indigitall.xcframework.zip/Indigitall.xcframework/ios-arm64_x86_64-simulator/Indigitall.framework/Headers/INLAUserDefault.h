//
//  INLAUserDefault.h
//  IndigitallSdk
//
//  Created by indigitall on 12/2/25.
//

#import <Foundation/Foundation.h>

#import "INDefaults.h"
#import "INLiveActivity.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLAUserDefault : INDefaults

+ (void) setLAPushToken:(NSDictionary *) pushToken;
+ (NSDictionary *) getLAPushToken;

+ (void) setLASubscribed:(NSArray<INLiveActivity *> *) liveActivities;
+ (NSArray<NSString *> *)getLASubscribed;

+ (void) setUpdateDeviceSubscribeFlag:(BOOL) active;
+ (BOOL) isUpdateDeviceSubscribeFlag;
@end

NS_ASSUME_NONNULL_END
