//
//  INLAUtils.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>
#import "INLADevice.h"
#import "INHmacUtils.h"
#import "INError.h"
#import "INLAUserDefault.h"
#import "INLiveActivity.h"

NS_ASSUME_NONNULL_BEGIN

@interface INLAUtils : NSObject
+ (void) setExternalCode: (NSString *) code withOnSuccess: (nullable void(^)(INLADevice * device))onSuccess withError: (nullable void(^)(INError *error))onError ;
+ (NSString *) generateUUID;
+ (NSArray<NSString*> *) getLASubscribedFromMemory: (NSArray<INLiveActivity *> *) liveActivities;
+ (BOOL) isLiveActivitiesSubscribed: (NSArray *) liveActivities;
@end

NS_ASSUME_NONNULL_END
