//
//  INBaseEventRequest.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 12/1/26.
//

#import <Foundation/Foundation.h>
#import "INBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface INBaseEventRequest : INBaseRequest

@property (nonatomic, nullable) NSString *eventId;
@property (nonatomic, nullable) NSString *eventAt;
@end

NS_ASSUME_NONNULL_END
