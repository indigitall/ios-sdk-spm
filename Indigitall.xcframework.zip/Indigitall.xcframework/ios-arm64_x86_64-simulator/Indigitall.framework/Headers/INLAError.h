//
//  INLAError.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>
#import "INLAErrorCode.h"
#import "INError.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLAError : INError
@property (readwrite, nonatomic) INLAErrorCode laErrorCode;

- (id)initWithErrorCode:(INLAErrorCode)errorCode descriptionMessage:(nullable NSString *)descriptionMessage;

@end

NS_ASSUME_NONNULL_END
