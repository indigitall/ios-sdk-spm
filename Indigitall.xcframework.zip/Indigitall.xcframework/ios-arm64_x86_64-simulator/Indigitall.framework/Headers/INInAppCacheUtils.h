//
//  INInAppCacheUtils.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 9/5/25.
//

#import <Foundation/Foundation.h>
#import "INInApp.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppCacheUtils : NSObject

@property (nonatomic) long TIME_CACHE;

+ (INInApp *) inAppWasCached: (NSString *)schemaCode;
+ (void) addNewInAppToCache: (INInApp *) inApp;
+ (void) deleteInAppFromCache: (INInApp *) inApp;
@end

NS_ASSUME_NONNULL_END
