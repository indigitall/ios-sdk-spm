//
//  INInAppValidations.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 21/3/25.
//

#import <Foundation/Foundation.h>
#import "INValidations.h"
#import "INInApp.h"
NS_ASSUME_NONNULL_BEGIN

@interface INInAppValidations : INValidations

+ (BOOL) isValidFormatWithExternalIdRequest;

@end

NS_ASSUME_NONNULL_END
