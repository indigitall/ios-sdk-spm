//
//  INLiveActivity.h
//  IndigitallSdk
//
//  Created by indigitall on 12/2/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface INLiveActivity : NSObject

@property (nonatomic, readonly) NSString * JSON_LA_ID;
@property (nonatomic, readonly) NSString * JSON_CREATED_AT;
@property (nonatomic, readonly) NSString * JSON_UPDATED_AT;
@property (nonatomic, readonly) NSString * JSON_APPLICATION_ID;
@property (nonatomic, readonly) NSString * JSON_LIVE_ACTIVITY_EXTERNAL_ID;
@property (nonatomic, readonly) NSString * JSON_STATUS;
@property (nonatomic, readonly) NSString * JSON_IOS_CHANNEL;

@property (nonatomic, nullable) NSString *liveActivityId;
@property (nonatomic, nullable) NSString *createdAt;
@property (nonatomic, nullable) NSString *updatedAt;
@property (nonatomic) int applicationId;
@property (nonatomic, nullable) NSString *liveActivityExternalId;
@property (nonatomic, nullable) NSString *status;
@property (nonatomic, nullable) NSString *iOSChannelId;

- (id) initWithDictionary: (NSDictionary *) data;
@end

NS_ASSUME_NONNULL_END
