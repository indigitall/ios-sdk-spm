//
//  INLARequestDevice.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>
#import "INBaseRequest.h"
#import "INLADevice.h"
#import "INLiveActivity.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLARequestDevice : INBaseRequest
@property (nonatomic) INLADevice *device;
@property (nonatomic) NSString *deviceId;
@property (nonatomic) NSString *tokenStart;
@property (nonatomic) NSString *iosAttributesType;
@property (nonatomic) NSArray<INLiveActivity*>* liveActivities;
@property (nonatomic) NSString *tokenUpdate;
@property (nonatomic) NSString *liveActivityExternalId;

- (id) init;
- (id) initWithLiveActivities: (NSArray<INLiveActivity*>*) liveActivities;
- (id) initWithPushtokenStart: (NSString *)token  withIosAttributesType:(NSString *)iosAttributesType;
- (id) initWithPushTokenUpdate: (NSString *)token liveActivityExternalId: (NSString *) liveActivityExternalId;
- (id) putStartTokenRequest;
- (id) putDeviceRequest;
- (id) putUpdateTokenRequest;

@end

NS_ASSUME_NONNULL_END
