//
//  INLAResponse.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>
#import "INBaseResponse.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLAResponse : INBaseResponse
- (id) initWithCallback: (INBaseCallback *_Nullable) callback;
- (void) processWithData:(NSData *_Nullable)data urlResponse:(NSString *)urlResponse error:(NSError *_Nullable)error;

@end

NS_ASSUME_NONNULL_END
