//
//  INEncryptionType.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 15/12/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


typedef NS_ENUM(NSInteger, INEncryptionType) {
    INEncryptionTypeRAW,
    INEncryptionTypeHASH,
    INEncryptionTypeUnknown
};

FOUNDATION_EXPORT NSString * _Nonnull const INEncryptionTypeStrings[];
FOUNDATION_EXPORT NSUInteger const INEncryptionTypeCount;

@interface INEncryptionTypeHelper : NSObject

+ (NSString *)stringFromType:(INEncryptionType)type;
+ (INEncryptionType)typeFromString:(nullable NSString *)string;

@end
NS_ASSUME_NONNULL_END
