//
//  INLADevice.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//
#import <Foundation/Foundation.h>
#import "INCoreDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface INLADevice : INCoreDevice

- (id)init;

@end

@interface INDeviceLAPushToken: NSObject

@property (nonatomic, nullable) NSString *iosAttributesType;
@property (nonatomic, nullable) NSString *token;

- (id) initWithDictionary: (NSDictionary * _Nullable) dictionary;
+ (id) toDictionaryWithToken: (NSString *) token withIosAttributestype: (NSString *)iosAttributesType;
@end

NS_ASSUME_NONNULL_END
