//
//  INLAErrorCode.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum {
    LIVE_ACTIVITY_GENERAL_ERROR = 5000,
    EXTERNAL_CODE_GENERATING_ERROR = 5001,
} INLAErrorCode;
extern NSString* _Nonnull const FormatStateLAError_toString[];
NS_ASSUME_NONNULL_END
