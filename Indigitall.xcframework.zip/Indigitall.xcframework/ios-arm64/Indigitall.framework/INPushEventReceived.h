//
//  INPushEventReceived.h
//  IndigitallSdk
//
//  Created by Carlos on 18/6/25.
//

#import <Foundation/Foundation.h>
#import "INPushDefaults.h"
#import <INPush.h>
#import <INRequestEvent.h>
#import <INAPIClient.h>

NS_ASSUME_NONNULL_BEGIN

@interface INPushEventReceived: NSObject

@property (nonatomic) INPush *pushNotification;
@property (nonatomic) NSDate *dateReceived;
@property (nonatomic) long creationTimestamp;

@property (class, nonatomic, readonly) long EXPIRATION_TIME_MS;
@property (class, nonatomic, readonly, copy) NSString *PUSH_NOTIFICATION;
@property (class, nonatomic, readonly, copy) NSString *DATE_RECEIVED;
@property (class, nonatomic, readonly, copy) NSString *CREATION_TIMESTAMP;

- (instancetype)initWithPushNotification:(INPush *)pushNotification dateReceived:(NSDate *)dateReceived creationTimestamp:(long) creationTimestamp;

- (void)addToEventQueue;

+ (void)sendEventQueue;

@end

NS_ASSUME_NONNULL_END
