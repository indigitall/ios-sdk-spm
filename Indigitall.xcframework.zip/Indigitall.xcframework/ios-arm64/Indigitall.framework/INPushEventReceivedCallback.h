//
//  INPushEventReceivedCallback.h
//  IndigitallSdk
//
//  Created by Carlos on 23/6/25.
//


#import "INPushDefaults.h"
#import "INEventCallback.h"
NS_ASSUME_NONNULL_BEGIN

@interface INPushEventReceivedCallback : INEventCallback

@property NSString *pushID;

- (id)initWithOnSuccess: (void(^)(void))onSuccess onError:(void(^)(INError * error))onError;
- (void) proccessDataWithStatusCode:(int)statusCode message:(NSString *)message data:(NSMutableDictionary *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
