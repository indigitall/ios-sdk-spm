//
//  LAIndigitall.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import <Foundation/Foundation.h>
#import "INLiveActivity.h"
#import "INLAError.h"
#import "INLADevice.h"

NS_ASSUME_NONNULL_BEGIN
@interface LAIndigitall : NSObject

+ (void) logInWithExternalCode: (NSString *) code withOnSuccess: (void(^)(INLADevice * device))onSuccess withError:(nullable void(^)(INError *error))onError;
+ (void) logOutWithOnSuccess: (void(^)(INLADevice * device))onSuccess withError:(nullable void(^)(INError *error))onError;

+ (void) getListEnabledLiveActivitiesWithOnSuccess: (void(^)(NSArray<INLiveActivity *>* liveActivity))onSuccess withError:(nullable void(^)(INError *error))onError;

+ (void) subscribeToLiveActivitiesWithLiveActivities: (NSArray<INLiveActivity *> *) liveActivities
                                       withOnSuccess: (void(^) (INLiveActivity * liveActivity)) onSuccess
                                           withError:(nullable void(^)(INError *error))onError;
+ (void) setPushToStartTokenUpdatesWithToken: (NSString *) token
                       withIosAttributesType: (NSString *) iosAttributesType
                               withOnSuccess: (void(^) (void)) onSuccess
                                   withError: (nullable void(^)(INError *error))onError;
+ (void) setPushTokenUpdatesWithToken: (NSString *) token
          withLiveActivityExternalId: (NSString *) liveActivityExternalId
                       withOnSuccess: (void(^) (void)) onSuccess
                            withError: (nullable void(^)(INError *error))onError;
@end

NS_ASSUME_NONNULL_END
