//
//  INPushDefaults.h
//  Indigitall
//
//  Created by indigitall on 20/6/22.
//  Copyright © 2022 Indigital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "INDefaults.h"
#import "INKeyChainService.h"
NS_ASSUME_NONNULL_BEGIN

@interface INPushDefaults : INDefaults

@property (nonatomic)NSString *pushTokenKey;
@property (nonatomic)NSString *pushPermissionAskedKey;
@property (nonatomic)NSString *pushPermissionStatusSentKey;
@property (nonatomic)NSString *pushPermissionModeKey;
@property (nonatomic)NSString *forceSimulatorToken;
@property (nonatomic)NSString *networkUpdateMinutesKey;
@property (nonatomic)NSString *networkEventsEnabledKey;
@property (nonatomic)NSString *networkSSIDKey;
@property (nonatomic)NSString *wifiFilterEnabledKey;
@property (nonatomic)NSString *deviceJsonKey;
@property (nonatomic)NSString *secureKeyKey;
@property (nonatomic)NSString *secureDataKey;
@property (nonatomic)NSString *putRequestKey;
@property (nonatomic)NSString *DEVICE_ENABLED_KEY;



+ (void) setPushToken:(NSString *) pushToken;
+ (NSString *) getPushToken;

+ (BOOL) getPushPermissionAsked;
+ (void) setPushPermissionAsked:(BOOL) pushPermissionAsked;

+ (int) getPushPermissionStatus;
+ (void) setPushPermissionStatus:(int) pushPermissionStatus;

+ (int) getPushPermissionMode;
+ (void) setPushPermissionMode:(int ) pushPermissionMode;

+ (void) setNetworkUpdateMinutes:(int)networkEventsEnabled;
+ (int) getNetworkUpdateMinutes;

+ (void) setWifiFilterEnabled:(BOOL)wifiFilterEnabled ;
+ (BOOL) getWifiFilterEnabled;

+ (void) setNetworkEventsEnabled:(BOOL)networkEventsEnabled;
+ (BOOL) getNetworkEventsEnabled;

+ (void) setNetworkSSID:(NSString *)networkSSID;
+ (NSString *) getNetworkSSID;

+ (void) setForceSimulatorToken :(BOOL)forceSimulatorToken ;
+ (BOOL) getForceSimulatorToken;

+ (void) setDisabledPushService :(BOOL)disabledPushService ;
+ (BOOL) getDisabledPushService;

+ (void) setDeviceJson:(NSString *_Nullable)deviceJson;
+ (NSString *) getDeviceJson;

+ (void) setSecureKey: (NSString *)setSecureKey;
+ (NSString *) getSecureKey;

+ (void) setSecureData: (NSString *)secureData;
+ (NSString *) getSecureData;

+ (int64_t) getPutRequestTimestamp;
+ (void) setPutRequestTimestamp:(int64_t) putRequest;

+ (void) setDeviceEnabled: (NSNumber *_Nullable)deviceStatus;
+ (NSNumber * _Nullable) getDeviceEnabled;

+ (void) setEventQueue: (NSDictionary *) eventQueue;
+ (NSDictionary *_Nullable) getEventQueue;
+ (void)removeFromEventQueue: (NSString*)pushID;

@end

NS_ASSUME_NONNULL_END
