//
//  INLATokenCallback.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 31/3/25.
//

#import <Foundation/Foundation.h>
#import "INBaseCallback.h"
#import "INLiveActivity.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLATokenCallback : INBaseCallback

typedef void(^onErrorLATokenDevice)(INError * error);
@property (readwrite, copy) onErrorLATokenDevice onError;

typedef void(^onSuccessLATokenDevice)(INLiveActivity * liveActivity);
@property (readwrite, copy) onSuccessLATokenDevice onSuccess;

- (id) initWithOnSuccess: (void(^)(INLiveActivity * liveActivity))onSuccess onError:(void(^)(INError * error))onError;

- (void) proccessDataWithStatusCode:(int)statusCode message:(NSString *)message data:(NSMutableDictionary *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
