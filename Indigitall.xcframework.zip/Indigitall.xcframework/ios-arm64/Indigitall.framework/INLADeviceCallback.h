//
//  INLADeviceCallback.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 25/3/25.
//

#import "INBaseCallback.h"
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface INLADeviceCallback : INBaseCallback

typedef void(^onErrorLADevice)(INError * error);
@property (readwrite, copy) onErrorLADevice onError;

typedef void(^onSuccessLADevice)(void);
@property (readwrite, copy) onSuccessLADevice onSuccess;

- (id) initWithOnSuccess: (void(^)(void))onSuccess onError:(void(^)(INError * error))onError;

- (void) proccessDataWithStatusCode:(int)statusCode message:(NSString *)message data:(NSMutableDictionary *_Nullable)data;
@end

NS_ASSUME_NONNULL_END
