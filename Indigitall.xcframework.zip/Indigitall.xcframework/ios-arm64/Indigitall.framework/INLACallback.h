//
//  INLACallback.h
//  IndigitallSdk
//
//  Created by indigitall on 12/2/25.
//

#import <Foundation/Foundation.h>
#import "INBaseCallback.h"
#import "INLiveActivity.h"
#import "INLAError.h"

NS_ASSUME_NONNULL_BEGIN

@interface INLACallback : INBaseCallback
@property (nonatomic) NSArray<INLiveActivity *>* liveActivities;

typedef void(^onErrorLA)(INLAError * error);
@property (readwrite, copy) onErrorLA onError;

typedef void(^onSuccessLA)(NSArray<INLiveActivity *>* liveActivities);
@property (readwrite, copy) onSuccessLA onSuccess;

- (id)initWithOnSuccess: (void(^)(NSArray<INLiveActivity *>* liveActivities))onSuccess onError:(void(^)(INLAError * error))onError;
- (void) proccessDataWithStatusCode:(int)statusCode message:(NSString *)message data:(NSMutableDictionary *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
