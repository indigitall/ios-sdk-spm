//
//  INInAppDefaults+Private.h
//  Indigitall
//
//  Created by Guillermo Claros on 9/6/26.
//  Copyright © 2022 Indigital. All rights reserved.
//
//  PRIVATE HEADER - Only for internal SDK use
//  NOT FOR PUBLIC API
//

#import <Foundation/Foundation.h>
#import "INInAppDefaults.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppDefaults (Private)

+ (void) setDebugLogToken:(NSString * _Nullable) token;
+ (NSString * _Nullable) getDebugLogToken;

@end

NS_ASSUME_NONNULL_END
