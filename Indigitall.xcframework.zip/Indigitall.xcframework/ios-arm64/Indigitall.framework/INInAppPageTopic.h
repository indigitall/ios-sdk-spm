//
//  INInAppPageTopic.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 20/8/25.
//

#import <Foundation/Foundation.h>
#import "INInAppTopic.h"
#import "INInAppDefaults.h"
#import "INInAppError.h"
#import "INInAppAPIClient.h"
#import "INRequestInAppTopicList.h"


NS_ASSUME_NONNULL_BEGIN


@interface INInAppPageTopic : NSObject

@property (nonatomic, strong) NSArray<INInAppTopic *> *topics;
@property (nonatomic, assign) int currentPage;
@property (nonatomic, assign) int total;
@property (nonatomic, assign) int pageSize;
@property (nonatomic, assign) double totalPages;

@property (nonatomic, copy) void (^onError)(INInAppError * error);
@property (nonatomic, copy, nullable) void (^onSuccess)(INInAppPageTopic *inAppPageTopic);

- (instancetype)initWithTopics:(NSArray<INInAppTopic *> *)topics
                   currentPage:(int)currentPage
                         total:(int)total
                     onSuccess: (nullable void(^)(INInAppPageTopic *inAppPageTopic)) onSuccess
                       onError: (nullable void(^)(INInAppError * error)) onError;
                            

- (BOOL)hasNextPage;

- (void)loadNextPage;


@end

NS_ASSUME_NONNULL_END
