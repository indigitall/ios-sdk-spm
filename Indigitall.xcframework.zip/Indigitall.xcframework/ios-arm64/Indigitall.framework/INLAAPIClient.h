//
//  INLAAPIClient.h
//  IndigitallSdk
//
//  Created by indigitall on 12/2/25.
//

#import <Foundation/Foundation.h>
#import "INLARequest.h"
#import "INLARequestDevice.h"
#import "INLAResponse.h"
#import "INLADeviceCallback.h"
#import "INLACallback.h"
#import "INLATokenCallback.h"
#import "INBaseClient.h"
NS_ASSUME_NONNULL_BEGIN

@interface INLAAPIClient : INBaseClient

+ (void) getListOfLiveActivitiesWithRequest: (INLARequest *)request withCompletion: (INLACallback *)callback;
+ (void) updateDevicePushLiveService: (INLARequestDevice *) request withCompletion: (INLATokenCallback *) callback;
+ (void) updateStartTokenPushLiveService: (INLARequestDevice *) request withCompletion: (INLADeviceCallback *) callback;
+ (void) updatePushTokenLiveActivities: (INLARequestDevice *) request withCompletion: (INLADeviceCallback *) callback;
@end

NS_ASSUME_NONNULL_END
