//
//  INInAppLog.h
//  IndigitallSdk
//
//  Created by Guillermo Claros on 9/6/26.
//

#import <Foundation/Foundation.h>
#import "INLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface INInAppLog : INLog

@property (nonatomic) BOOL hidden;
@property (nonatomic) BOOL disableRemoteSend;
- (id)init: (NSString *)tag;
- (void)Log: (NSString *)tag level:(int) level;
- (void) writelog;

- (void)d: (NSString *)message;
- (void)i: (NSString *)message;
- (void)w: (NSString *)message;
- (void)e: (NSString *)message;
- (void)error: (INError *)message;
- (void)setLevelLog:(int)newLevel;


@end

NS_ASSUME_NONNULL_END
