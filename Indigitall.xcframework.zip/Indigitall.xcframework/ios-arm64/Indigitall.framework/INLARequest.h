//
//  INLARequest.h
//  IndigitallSdk
//
//  Created by indigitall on 12/2/25.
//

#import <Foundation/Foundation.h>

#import "INBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface INLARequest : INBaseRequest
- (id) init;
-(id) getListLiveActivity;
@end

NS_ASSUME_NONNULL_END
